#!/bin/sh

docker build -t wrecksys .
aws sso login
aws ecr get-login-password --region us-east-2 | docker login --username AWS --password-stdin 757938331536.dkr.ecr.us-east-2.amazonaws.com
docker tag wrecksys:latest 757938331536.dkr.ecr.us-east-2.amazonaws.com/wrecksys:latest
docker push 757938331536.dkr.ecr.us-east-2.amazonaws.com/wrecksys:latest
